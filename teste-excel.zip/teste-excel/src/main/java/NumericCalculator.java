

public class NumericCalculator {
	public int add(int a, int b) {
		return a + b;
	}
}
